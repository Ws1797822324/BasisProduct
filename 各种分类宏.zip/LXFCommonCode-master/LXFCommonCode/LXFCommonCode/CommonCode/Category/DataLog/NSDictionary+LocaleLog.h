//
//  NSDictionary+LocaleLog.h
//  控制台打印字典
//
//  Created by LXF on 17/3/2.
//  Copyright © 2017年 LXF. All rights reserved.
//
//  GitHub: https://github.com/LinXunFeng
//  简书: http://www.jianshu.com/users/31e85e7a22a2

#import <Foundation/Foundation.h>

@interface NSDictionary (LocaleLog)
- (NSString *)descriptionWithLocale:(id)locale;
@end
